﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LitJson;
using System.IO;

public class Foodd
{
    public int Recovery;
    public string Name;

    public int Count;

    public Foodd(int recovery,string name,int count)
    {
        Recovery = recovery;
        Name = name;

        Count = count;
    }
}

public class FoodData : MonoBehaviour
{
    public List<Foodd> FoodList = new List<Foodd>();
    public List<Foodd> ChangeList = new List<Foodd>();
    public Foodd fd;

    string name;
    int recovery;
    int count;

    // Use this for initialization
    void Start ()
    {
       

        
    }

    public void save()
    {
        //StartCoroutine(FoodSave());
    }

    public void load()
    {
        StartCoroutine(FoodLoad());
    }

    public void change()
    {
        StartCoroutine(FoodChange());
    }

    private string ToKor(Foodd f)
    {

        JsonData ch1 = JsonMapper.ToJson(fd);

        string tmpstring = ch1.ToString();

        string[] tmpcomma = tmpstring.Split(',');

        string[] tmpcolon = tmpcomma[1].Split(':');

        string res = tmpcolon[0] + ":" + "'" + fd.Name + "'";

        string ress = tmpcomma[0] + "," + res + "," + tmpcomma[2];

        return ress;

    }

    IEnumerator FoodChange()
    {

        string FoodString = File.ReadAllText(Application.dataPath + "/Resources/FoodData.json");

        string sa="";

        JsonData ch = JsonMapper.ToObject(FoodString);
        
        Debug.Log(ch.Count);
        for (int i = 0; i < ch.Count; i++)
        {
            recovery = int.Parse(ch[i]["Recovery"].ToString());
            name = ch[i]["Name"].ToString();

            count = int.Parse(0.ToString());

            fd = new Foodd(recovery,name, count);

            sa +=ToKor(fd);

            //ChangeList.Add(fd);
        }
        



        File.WriteAllText(Application.dataPath + "/Resources/FoodData.json", sa.ToString());

        yield return null;

    }

    //IEnumerator FoodSave()
    //{

    //    for (int i = 0; i < InventoryManager.Instance.FData.FoodList.Length; i++)
    //    {
    //        recovery = InventoryManager.Instance.FData.FoodList[i].Recovery;
    //        name = InventoryManager.Instance.FData.FoodList[i].Name;
           
    //        count = InventoryManager.Instance.FData.FoodList[i].Count;

    //        fd = new Foodd(recovery,name, count);

    //        FoodList.Add(fd);

    //    }

    //    JsonData FoodJson = JsonMapper.ToJson(FoodList);

    //    File.WriteAllText(Application.dataPath + "/Resources/FoodData.json", FoodJson.ToString());

    //    yield return null;
    //}
    // Update is called once per frame

    IEnumerator FoodLoad()
    {

        string FoodString = File.ReadAllText(Application.dataPath + "/Resources/FoodData.json");

        Debug.Log(FoodString); // 첫 줄 출력

        JsonData itemData = JsonMapper.ToObject(FoodString);
        //태그로 정렬 가능?

        

        yield return null;

    }



}


