﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LitJson;
using System.IO;

public class Materiall
{


    


    public int Count;

    public string Name;
    public string Text;

    public Materiall(int count, string name, string text)
    {
       
        Count = count;
        Name = name;
        Text = text;
    }

}

public class MaterialData : MonoBehaviour {

    public List<Materiall> MaterialList = new List<Materiall>();
    public List<Materiall> ChangeList = new List<Materiall>();
    public Materiall mt;

    string name;
    string text;
    int count;
    // Use this for initialization
    void Start () {
		
	}

    public void save()
    {
        //StartCoroutine(MaterialSave());
    }

    public void load()
    {
        StartCoroutine(MaterialLoad());
    }

    public void change()
    {
        StartCoroutine(MaterialChange());
    }

    private string ToKor(Materiall m)
    {

        JsonData ch1 = JsonMapper.ToJson(m);

        string tmpstring = ch1.ToString();

        string[] tmpcomma = tmpstring.Split(',');

        

        string[] tmpcolon = tmpcomma[1].Split(':');

       

        string res = tmpcolon[0] + ":" + "'" + m.Name + "'";

       

        string ress = tmpcomma[0] + "," + res ;

        JsonData ch2 = JsonMapper.ToJson(m);

        string tmpstring2 = ch2.ToString();

        string[] tmpcomma2 = tmpstring2.Split(',');
        string[] tmpcolon2 = tmpcomma2[2].Split(':');
        string res2 = tmpcolon2[0] + ":" + "'" + m.Text + "'";

        ress += "," + res2;

        return ress;

    }

    IEnumerator MaterialChange()
    {

        string MaterialString = File.ReadAllText(Application.dataPath + "/Resources/MaterialData.json");

        string sa = "";

        JsonData ch = JsonMapper.ToObject(MaterialString);

        Debug.Log(ch.Count);
        for (int i = 0; i < ch.Count; i++)
        {
            
            name = ch[i]["Name"].ToString();

            count = int.Parse(0.ToString());

            text = ch[i]["Text"].ToString();

            mt = new Materiall(count, name, text);

            sa += ToKor(mt);
            

            //ChangeList.Add(fd);
        }




        File.WriteAllText(Application.dataPath + "/Resources/MaterialData.json", sa.ToString());

        yield return null;

    }

    //IEnumerator MaterialSave()
    //{

    //    for (int i = 0; i < InventoryManager.Instance.FData.MaterialList.Length; i++)
    //    {
    //        text = InventoryManager.Instance.FData.MaterialList[i].Text;
    //        name = InventoryManager.Instance.FData.MaterialList[i].Name;

    //        count = InventoryManager.Instance.FData.MaterialList[i].Count;

    //        mt = new Materiall(count, name, text);

    //        MaterialList.Add(mt);

    //    }

    //    JsonData MaterialJson = JsonMapper.ToJson(MaterialList);

    //    File.WriteAllText(Application.dataPath + "/Resources/MaterialData.json", MaterialJson.ToString());

    //    yield return null;
    //}
    // Update is called once per frame

    IEnumerator MaterialLoad()
    {

        string MaterialString = File.ReadAllText(Application.dataPath + "/Resources/MaterialData.json");

        Debug.Log(MaterialString); // 첫 줄 출력

        JsonData itemData = JsonMapper.ToObject(MaterialString);
        //태그로 정렬 가능?



        yield return null;

    }
}
