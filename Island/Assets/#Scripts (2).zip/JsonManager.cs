﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LitJson;
using System.IO;

public class Item
{
    public int ID;
    public string Name;
    public string Dis;

    public Item(int id, string name, string dis)
    {
        ID = id;
        Name = name;
        Dis = dis;
    }
}
//class 직업을 하나 더 만들어서
//class (고른직업)에서 숫자로 비교해서 불러오기?
//ID값만 비교해서 DB를 불러온다



public class JsonManager : MonoBehaviour
{
    public Item ii;
    public static JsonManager jm;
    //bool ispaused = false;
    public List<Item> ItemList = new List<Item>();

    public List<Item> Inventory = new List<Item>();


	// Use this for initialization
	void Start ()
    {

        if (jm == null)
        {
            DontDestroyOnLoad(gameObject);
            jm = this;
        }
        else if (jm != this)
        {
            Destroy(gameObject);
        }

    }

    public void SaveFunc()
    {
       
        Debug.Log("저장합니다");
        
        StartCoroutine(SaveCo());
        //파일이 있으면 덮어쓰기 / 없으면 새로 만들기

        
    }
    IEnumerator SaveCo()
    {
        int id=0;
        string name="";
        string dis="";

        
            id = 100;
            name = "지현우00";
            dis = "설명00";
       
        ii = (new Item(id, name, dis));

        ItemList.Add(ii);
        id = 10;
        name = "지현우0";
        dis = "설명0";

        ii = (new Item(id, name, dis));
        ItemList.Add(ii);
        id = 1;
        name = "지현우";
        dis = "설명";

        ii = (new Item(id, name, dis));
        ItemList.Add(ii);

        JsonData ItemJson = JsonMapper.ToJson(ItemList);//Json 파일 만들기 이 부분에서 한글이 깨진다.

        //string tempstring = ItemJson.ToString();
        //string[] tempComma = tempstring.Split(',');
        //string[] tempcolon = tempComma[1].Split(':');
        //string res = tempcolon[0] + ":" + "'" + name + "'";
        //string resstring = tempComma[0] + "," + res + "," + tempComma[2];

        File.WriteAllText(Application.dataPath + "/Resources/ItemData.json", ItemJson.ToString());



        yield return null;

    }
    //void OnApplicationPause(bool pause)
    //{

    //    if (pause)
    //    {
    //        ispaused = true;
    //        JsonData ItemJson = JsonMapper.ToJson(ItemList);//Json 파일 만들기

    //        File.WriteAllText(Application.dataPath + "/Resources/ItemData.json", ItemJson.ToString());
    //    }
    //    else
    //    {
    //        if (ispaused)
    //        {
    //            ispaused = false;
    //            JsonData ItemJson = JsonMapper.ToJson(ItemList);//Json 파일 만들기

    //            File.WriteAllText(Application.dataPath + "/Resources/ItemData.json", ItemJson.ToString());
    //        }
    //    }

    //}

    public void LoadFunc()
    {
        Debug.Log("불러옵니다");

        StartCoroutine(LoadCo());
    }

    

    IEnumerator LoadCo()
    {

        string JsonString = File.ReadAllText(Application.dataPath + "/Resources/ItemData.json");

        Debug.Log(JsonString); // 첫 줄 출력

        JsonData itemData = JsonMapper.ToObject(JsonString);
        //태그로 정렬 가능?

        ParsingJsonItem(itemData);

        yield return null;

    }

    private void ParsingJsonItem(JsonData name)
    {

        for (int i = 0; i < name.Count; i++)
        {
            
           Debug.Log(name[i]["Name"]);//i번째 "ID" 불러오기

            for (int j = 0; j < ItemList.Count; j++)
            {

                if (name[j]["ID"].ToString() == ItemList[j].ID.ToString())
                {
                    Inventory.Add(ItemList[i]);
                }

            }

        }


        for (int i = 0; i < ItemList.Count; i++)
        {

            Debug.Log(ItemList[i].ID+ ItemList[i].Name+ ItemList[i].Dis);//i번째 "ID" 불러오기

            

        }

    }


}
