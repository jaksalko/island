﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChooseCharSceneCanvas : MonoBehaviour {

	// Use this for initialization
	void Start () {
        Screen.SetResolution(720, 1280, true);
        Screen.orientation = ScreenOrientation.Portrait;
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
