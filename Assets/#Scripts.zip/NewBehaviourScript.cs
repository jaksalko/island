﻿using System.Collections;
using System.Collections.Generic;
using System.Xml;
using System.Security.Cryptography;
using UnityEngine;
using System.Text;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System.IO;
using System.Xml;
using System.Text;
using System.Xml.Serialization;
using System;


public class NewBehaviourScript : MonoBehaviour
{
    string[] n = { "디자이너","조선공", "요리사", "낚시꾼", "농부", "건축가", "공학자", "의사", "산적" };
    string[] pop = { "보기엔 허름해 보이지만 안 입는 것보다는 훨씬 나아요....얼른 입으세요..."
    , "요즘 유행하는 걸뱅이패션으로 만들어봤어요... 당신에게는 굉장히 잘어울릴 것 같군요.. :)"
    , "통풍이 잘되는 모시로 옷을 리폼해봤어요... 입어...주실 거죠?"
    , "한국전통의상이에요... 이건 꼭 입어야되는 거에요... 병에는 더더욱 안걸릴거에요.."
    , "병균이 들어오지도 못하는 옷을 만들어봤어요.. 이걸 입고 탈출하게되면 사람들이 뭐라 생각하려나요..?"

    , "뗏목을 만들었다네!!! 이 배로 나갈 수는 있지만 나는 나가기가 싫다네!!! 너나 나가라네!!!"
    , "이제 좀 배다워 진다네!! 만반의 준비를 하고 바다로 나가면 충분히 살 것 같다네!!"
    , "이 배를 타고 나가고 싶어진다네!! 배는 어떤 팀으로 타서 역할 분배를 하느냐도 중요하다네"
    , "배를 잘 보게나! 화장실, 침실까지 만들었다네! 저 침실에서 잤다깨서 화장실을 이용하고 싶은 기분이라네!"
    , "이 배는 누가만든거지?...?.....나라네!!!! 하하하핫 내가 만든 것이라고 안 믿길정도로 너무 잘 만든것 같다네!!!"

    , "요리가 맛있어 보이지 않나요? 꺼억..~ 미안해요... 음식하다가 몇개를 집어먹어서요... 하하하핫, 농담이에요~"
    , "요리가 완성됐어요~ 식사시간이에요~"
    , "어디서 맛있는 냄새가 나지요~? 하하핫 제가 만든 음식이에요~"
    , "제가 먹어본 요리들 중 제 요리가 제일 맛있지요~"
    , "요리가 완성됐어요~ 식사시간이에요~"

    , "다음에는 광어 팔짜를 잡아올거야!! 기대들 하고 있으라고!!"
    , "이 물고기는 단번에 낚아챈 물고기고, 저 물고기는 20분간 씨름하다 낚은 물고기야! 그리고 저 물고기는 ....."
    , "지난번에 낚시잡지 표지모델로 촬영했을 때 잡은 것보다 약간 작군!! "
    , "고기를 잡으러 산으로 갈까나~ ......? 산에는 물고기가 없군!!!"
        , "다음에는 광어 팔짜를 잡아올거야!! 기대들 하고 있으라고!!"

    , "이게 농부의 땀의 결실입니다. 음식을 먹을 때 항상 감사하세요."
    , "우리 자식들 내가 수확한 쌀밖에 못먹는데... 얼른 돌아가서 쌀 보내줘야지"
    , "이 쌀은 썩었고... 이 쌀은 맛있겠네요"
              , "우리 자식들 내가 수확한 쌀밖에 못먹는데... 얼른 돌아가서 쌀 보내줘야지"
    , "이 쌀은 썩었고... 이 쌀은 맛있겠네요"


    , "허름하긴 하지만 단기간내 지은 집 치고는 잘 지었군! 누가 지었는지 궁금하군!!"
    , "이전 집보다는 훨씬 안정감이 있어.. 10년은 끄떡없을 집이야"
    , "이 집에서 쉬게되면 다음날 기분이 항상 좋을 것 같은 느낌이야!! 느낌적인 느낌이지"
    , "좋다 좋아. 이정도면 모두들 나를 건축의 신이라 부를정도의 집이지"
    , "여태까지 내가 만든 집들 중에 TOP10에 들만한 집이지, 탈출할 때 들고 가고싶을 정도군!"

    , "초등학교때 영화를 보고 모스부호를 배웠지... 그때가 재밌었는데..."
    , "치지지지직... 누군가 이 무전을 받을 수 있겠구만"
    , "띠리리리리링...여보세요! 작동을 하는지 안하는지 알 수가 없고만"
    , "삐---삐--- 주파수를 잡는 것 같은데 어느 방향이 마을인지 알 수가 없으니 원..."
    , "지구내에서보다 우주에서 신호를 보내면 누구든 볼 수 밖에 없지!"

    , "입에 쓴 것이 몸에 좋은 것이지 >.< 얼른 드셔서 나으시라능"
    , "이 약을 먹으면 병이 낫지만 부작용이 있어요... 그 부작용은 ... 바로..."
    , "내 약에는 부작용이 없다능~ 하지만 있다면 내 말투를 따라할 수도 있다능~"
             , "이 약을 먹으면 병이 낫지만 부작용이 있어요... 그 부작용은 ... 바로..."
    , "내 약에는 부작용이 없다능~ 하지만 있다면 내 말투를 따라할 수도 있다능~"


    , "이 친구가 나를 애먹였어!!! 하지만 내가 이겼지 나는 육지에서 최고이니깐!!!"
    , "으할할할할핥!!! 날 여자라고 만만하게 봤다간 큰일난다고! 난 태어나서부터 산에서 자랐으니!!"
    , "이 섬에는 사냥할 동물이 많더군! 무인도를 무생도로 바꿔버리겠어!!",
             "이 친구가 나를 애먹였어!!! 하지만 내가 이겼지 나는 육지에서 최고이니깐!!!"
    , "으할할할할핥!!! 날 여자라고 만만하게 봤다간 큰일난다고! 난 태어나서부터 산에서 자랐으니!!"
    };

    string[] c = { "(옷이름)이 완성되었습니다. 병에 걸릴 확률이 줄어듭니다.(옷이 업그레이드됨에 따라 병에 걸리는 확률이 줄어듭니다.)"
    ,"(배이름)이 완성되었습니다. 배를 이용하여 낚시와 탈출을 할 수 있습니다.(배가 업그레이드됨에 따라 낚시를 나갔을 때 잡을 수 있는 최대 물고기양과 탈출 확률이 늘어납니다)"
    ,"요리가 완성되었습니다. 요리를 먹어 포만감을 회복할 수 있습니다."
    ,"물고기를 낚았습니다. 물고기를 먹거나, 요리를 할 수 있습니다."
    ,"쌀을 수확했습니다. 쌀은 요리를 통해 먹을 수 있습니다."
    ,"(집이름)이 완성되었습니다. 낮에 집에서 쉴 수 있고, 자고나면 다음날 컨디션이 좋아질 확률이 늘어납니다.(집이 업그레이드됨에 따라 다음 날 컨디션이 좋아질 확률이 늘어납니다)"
    ,"(통신장치 이름)이(가) 완성되었습니다. 통신장치를 이용해 탈출을 시도할 수 있습니다.(통신장치가 업그레이드됨에 따라 탈출 확률이 늘어납니다)"
    ,"약이 제약되었습니다. 약을 통해 병을 치료할 수 있습니다."
    ,"수렵에 성공하였습니다. 고기 20개를 얻었습니다.(이 고기는 요리를 할 수 있습니다.)"};


    string[] dwork = { "얼른 집을 지어서 편하게 자고 싶어. 밖에서 자다보니 자고 일어나도 기분이 좋지 않아"
                    ,""
    ,"집에서 자고 일어나면 일을 더 잘할 것 같은데... 언제쯤 완성되나?"
    ,"집이 완성되면 머리만 닿아도 곯아떨어질 수 있을 것 같군!"

    ,"얼른 배를 만들어야겠어 낚시를 하거나 탈출을 시도할 수 있을테니 말이야"
    ,"배가 거의 완성되어가고 있어. 재료가 남아있나..?"
    ,"배를 타고 낚시를 하면 물고기가 더 많이 잡힐 것 같은데 말야... 벌써부터 침이 고이는 구만!"

    ,"옷이 없어서 그런지 사람들이 잔병에 많이 걸리는 것 같아"
    ,"옷을 얼른 만들지 않으면 큰 병에 걸려서 약이 많이 필요하게 될거야"
    ,"병에 걸리지 않으려면 청결이 최우선이지! 얼른 옷을 입혀달라고!"

    ,"통신이 될지 안될지는 모르겠지만 일단 시도는 해봐야지! 내일도 서둘러야겠어"
    ,"조금만 더 진행하면 완성이 되겠어.. "
    ,"완성이 되면 뭐라고 구조요청을 해야 사람들이 믿어줄까..."

    ,"사람은 밥을 먹고 지내야지! 얼른얼른 자라다오!"
    ,"추수를 할 때 씨앗을 다시 수거해야지! 썩은 것이 적었으면 좋겠다!"
    ,"얼른 요리해서 맛있는 밥과 요리들을 먹자구!"};

    string[] dbasic = { "뭐라도 먹지않으면 기운이 빠질 것 같아"
    ,"아직까지는 버틸만해.."
    ,"배가 부르니 내일도 힘이 날 것 같군!"

    ,"목이 너무 말라... 물... 물을 마셔야해"
    ,"물은 한번 마시면 오래동안 괜찮아지니 아껴 마셔야할 것 같아."
    ,"얼른 약을 먹어야 해. 이런 오지에서 걸린 병은 낫기가 힘들다고.."

    ,"약을 잘 만드는 사람의 약을 먹어야 잘 나을 텐데..."
   };
    string[] state = { "배고픔","목마름","병"};
    string[] work = { "집 짓기","배 만들기","옷 만들기","통신장치 만들기","농사"};
    string[] timemachine = { "제대로 만들고 있는게 맞나?", "... 내가 설계했던 것과는 다른 결과물이 나올 것 같아.. 좋은 걸까?" };








    // Use this for initialization
    public void Awake()
    {
        //Load();
        Debug.Log("싱글톤 성공2");




    }

    // Update is called once per frame
    void Update()
    {

        
    }

    //void Load()//불러오기
    //{


    //    TextAsset textAsset = Resources.Load("MaterialInventory") as TextAsset;

    //    TextAsset TtextAsset = Resources.Load("ToolInventory") as TextAsset;
    //    print(textAsset.text);

    //    XmlSerializer ser = new XmlSerializer(typeof(MaterialInfo));

    //    XmlSerializer Tser = new XmlSerializer(typeof(ToolInfo));

    //    mData = ser.Deserialize(new StringReader(textAsset.text)) as MaterialInfo;

    //    TData = Tser.Deserialize(new StringReader(TtextAsset.text)) as ToolInfo;

    //    foreach (Material mat in mData.MaterialList)
    //    {
    //        Debug.Log("name :" + mat.Name);
    //        Debug.Log("Count :" + mat.Count);
    //        Debug.Log("Text :" + mat.Text);
    //    }
    //    foreach (Tool too in TData.ToolList)
    //    {
    //        Debug.Log("이름 :" + too.Name);
    //        Debug.Log("Grade :" + too.Grade);
    //        Debug.Log("Count :" + too.Count);

    //    }
    //}



    public static string encryData(string toEncrypt)
    {
        byte[] keyArray = UTF8Encoding.UTF8.GetBytes("dotdopdeep");

        byte[] toEmcryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);
        RijndaelManaged rDel = new RijndaelManaged();

        rDel.Key = keyArray;
        rDel.Mode = CipherMode.ECB;

        rDel.Padding = PaddingMode.PKCS7;

        ICryptoTransform cTransform = rDel.CreateEncryptor();

        byte[] resultArray = cTransform.TransformFinalBlock(toEmcryptArray, 0, toEmcryptArray.Length);

        return Convert.ToBase64String(resultArray, 0, resultArray.Length);
    }

    void CreateXml()
    {
        XmlDocument xmlDoc = new XmlDocument();

        xmlDoc.AppendChild(xmlDoc.CreateXmlDeclaration("1.0", "utf-8", "yes"));

        //루트 노드 생성
        XmlNode root = xmlDoc.CreateNode(XmlNodeType.Element, "FoodInventory", string.Empty);
        xmlDoc.AppendChild(root);

       




        xmlDoc.Save("./Assets/Resources/FoodInventory.xml");

    }

    public void xmlmod()
    {
        TextAsset textAsset = (TextAsset)Resources.Load("Character");

        
        XmlDocument xmlDoc = new XmlDocument();
        xmlDoc.LoadXml(textAsset.text);
        
        
        //노드 선택   -> 루트/선택할노드
        XmlNodeList child = xmlDoc.SelectNodes("CharacterInfo/Character");
        XmlNode character = child[0];

        //디버그문 출력
        Debug.Log(character.SelectSingleNode("Name").InnerText);

        //노드의 원소 데이터 변경
        character.SelectSingleNode("Name").InnerText = "wlgusdn9";

        character.SelectSingleNode("Level").InnerText = "10";
        character.SelectSingleNode("Experience").InnerText = "100";

        xmlDoc.Save("./Assets/Resources/CharacterInfo.xml");


    }

    void inout()
    {


        XmlDocument xmlDoc = new XmlDocument();
        string filepath = Application.dataPath.ToString() + "/Resources/FoodInventory.xml";
        xmlDoc.Load(filepath);
        XmlElement elmRoot = xmlDoc.DocumentElement;

        //string data;
        //복호화
        //data = Decrypt(elmRoot.InnerText);
        //elmRoot.InnerXml = data;
        //xmlDoc.Save(filepath);

        XmlNodeList child = xmlDoc.SelectNodes("FoodInventory/Food");
        
        

        

        Debug.Log(child[0].SelectSingleNode("고래등1").InnerText);
       
        Debug.Log(child[0].SelectSingleNode("고래등2").InnerText);
        
        Debug.Log(child[0].SelectSingleNode("고래등3").InnerText);

        Debug.Log(child[0].SelectSingleNode("고래등성공엔딩").InnerText);




        //암호화
        //data = encryData(elmRoot.InnerXml);
        //elmRoot.RemoveAll();
        //elmRoot.InnerText = data;
        //xmlDoc.Save(filepath);
    }

    public static string Decrypt(string toDecrypt)
    {
        byte[] keyArray = UTF8Encoding.UTF8.GetBytes("dotdopdeep");

        byte[] toEncryptArray = Convert.FromBase64String(toDecrypt);

        RijndaelManaged rDel = new RijndaelManaged();
        rDel.Key = keyArray;
        rDel.Mode = CipherMode.ECB;

        rDel.Padding = PaddingMode.PKCS7;

        ICryptoTransform cTransform = rDel.CreateDecryptor();

        byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

        return UTF8Encoding.UTF8.GetString(resultArray);
    }
}
