﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {
    bool isPaused = false;
    // Use this for initialization
    void Start ()
    {
        //for (int i = 0; i < InventoryManager.Instance.TData.ToolList.Length; i++)
        //{
        //    Debug.Log(InventoryManager.Instance.TData.ToolList[i].Count);
        //    Debug.Log(InventoryManager.Instance.TData.ToolList[i].Grade);
        //    Debug.Log(InventoryManager.Instance.TData.ToolList[i].Name);
        //}
        //for (int i = 0; i < InventoryManager.Instance.mData.MaterialList.Length; i++)
        //{
        //    Debug.Log(InventoryManager.Instance.mData.MaterialList[i].Count);
        //    Debug.Log(InventoryManager.Instance.mData.MaterialList[i].Text);
        //    Debug.Log(InventoryManager.Instance.mData.MaterialList[i].Name);
        //}
        //for (int i = 0; i < InventoryManager.Instance.FData.FoodList.Length; i++)
        //{
        //    Debug.Log(InventoryManager.Instance.FData.FoodList[i].Name);
        //    Debug.Log(InventoryManager.Instance.FData.FoodList[i].Count);
        //    Debug.Log(InventoryManager.Instance.FData.FoodList[i].Recovery);
        //}
        for (int i = 0; i < CharacterManager.Instance.CData.CharacterList.Length; i++)
        {
            Debug.Log(CharacterManager.Instance.CData.CharacterList[i].Name);
            Debug.Log(CharacterManager.Instance.CData.CharacterList[i].MStat);
            Debug.Log(CharacterManager.Instance.CData.CharacterList[i].Sstat);
            Debug.Log(CharacterManager.Instance.CData.CharacterList[i].Estat);
            Debug.Log(CharacterManager.Instance.CData.CharacterList[i].Form);
        }

        
    }
    //void OnApplicationPause(bool pause)
    //{
    //    if (pause)
    //    {

            
    //        isPaused = true;

    //    }

    //    else
    //    {
    //        if (isPaused)
    //        {
    //            isPaused = false;
    //            /* 앱이 활성화 되었을 때 처리 */
                
    //        }
    //    }
    //}
    // Update is called once per frame
    void Update ()
    {

        

    }
}
