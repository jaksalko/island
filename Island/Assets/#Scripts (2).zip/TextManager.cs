﻿using System.Collections;
using System.Collections.Generic;
using System.Xml;
using System.Security.Cryptography;
using UnityEngine;
using System.Text;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System.IO;
using System.Xml;
using System.Text;
using System.Xml.Serialization;
using System;
using TMPro;

public class TextManager : SingleTon<TextManager>
{
    //public List<TextMeshProUGUI> MaterialCountText;
    public TextMeshProUGUI[] FoodCountText;

    
    void Awake()
    {
        //InventoryManager.Instance.Load();

    }
    void Update ()
    {

        //for (int i = 0; i < FoodCountText.Length; i++)
        //{

        //    TextManager.Instance.FoodCountText[i].text = InventoryManager.Instance.FData.MaterialList[i].Count.ToString();

        //}
        //for (int i = 0; i < MaterialCountText.Count; i++)
        //{

        //    TextManager.Instance.MaterialCountText[i].text = InventoryManager.Instance.mData.MaterialList[i].Count.ToString();

        //}
    }
    
    // Update is called once per frame
    
}
