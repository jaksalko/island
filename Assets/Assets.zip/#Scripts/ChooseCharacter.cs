﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChooseCharacter : MonoBehaviour {

    //public Button[] choose;

    //// Use this for initialization
    //void Start()
    //{

    //}
    //void Update()
    //    {
    //    for (int i = 0; i < CharacterData.Instance.MyCharacter.Count; i++)
    //    {
    //        Debug.Log(CharacterData.Instance.MyCharacter[i]);
    //    }
        
    //    }
    //public void press(Button bu)
    //{
    //    switch (bu.ToString())
    //    {
    //        case ("Button (UnityEngine.UI.Button)"):
    //            {
    //                CharacterData.Instance.MyCharacter.Add(1);
    //                break;
    //            }
    //        case ("Button (1) (UnityEngine.UI.Button)"):
    //            {
    //                CharacterData.Instance.MyCharacter.Add(2);
    //                break;
    //            }
    //        case ("Button (2) (UnityEngine.UI.Button)"):
    //            {
    //                CharacterData.Instance.MyCharacter.Add(3);
    //                break;
    //            }
    //        case ("Button (3) (UnityEngine.UI.Button)"):
    //            {
    //                CharacterData.Instance.MyCharacter.Add(4);
    //                break;
    //            }
    //        case ("Button (4) (UnityEngine.UI.Button)"):
    //            {
    //                CharacterData.Instance.CharacterName.Add(5);
    //                break;
    //            }
    //        case ("Button (5) (UnityEngine.UI.Button)"):
    //            {
    //                CharacterData.Instance.CharacterName.Add(6);
    //                break;
    //            }
    //        case ("Button (6) (UnityEngine.UI.Button)"):
    //            {
    //                CharacterData.Instance.CharacterName.Add(7);
    //                break;
    //            }
    //        case ("Button (7) (UnityEngine.UI.Button)"):
    //            {
    //                CharacterData.Instance.CharacterName.Add(8);
    //                break;
    //            }
    //        case ("Button (8) (UnityEngine.UI.Button)"):
    //            {
    //                CharacterData.Instance.CharacterName.Add(9);
    //                break;
    //            }
    //        case ("Button (9) (UnityEngine.UI.Button)"):
    //            {
    //                CharacterData.Instance.CharacterName.Add(10);
    //                break;
    //            }

    //    }

        

    //}
	
}
